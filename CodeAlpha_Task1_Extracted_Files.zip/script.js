const languages = [
  ["af","Afrikaans"],["ar","Arabic"],["bn","Bengali"],["zh","Chinese (Simplified)"],
  ["nl","Dutch"],["en","English"],["fr","French"],["de","German"],["el","Greek"],
  ["gu","Gujarati"],["he","Hebrew"],["hi","Hindi"],["id","Indonesian"],["it","Italian"],
  ["ja","Japanese"],["kn","Kannada"],["ko","Korean"],["ml","Malayalam"],["mr","Marathi"],
  ["ne","Nepali"],["fa","Persian"],["pl","Polish"],["pt","Portuguese"],["pa","Punjabi"],
  ["ru","Russian"],["es","Spanish"],["sw","Swahili"],["ta","Tamil"],["te","Telugu"],
  ["th","Thai"],["tr","Turkish"],["uk","Ukrainian"],["ur","Urdu"],["vi","Vietnamese"]
];

const sourceSelect = document.getElementById("sourceLanguage");
const targetSelect = document.getElementById("targetLanguage");
const sourceText = document.getElementById("sourceText");
const translatedText = document.getElementById("translatedText");
const translateButton = document.getElementById("translateButton");
const message = document.getElementById("message");
const copyButton = document.getElementById("copyButton");
const speakButton = document.getElementById("speakButton");
let lastTranslation = "";

function fillLanguages() {
  for (const [code, name] of languages) {
    const sourceOption = new Option(name, code);
    const targetOption = new Option(name, code);
    sourceSelect.add(sourceOption);
    targetSelect.add(targetOption);
  }
  sourceSelect.value = "autodetect";
  targetSelect.value = "hi";
}
fillLanguages();

sourceText.addEventListener("input", () => {
  document.getElementById("charCount").textContent = `${sourceText.value.length} / 5000`;
});
function setMessage(text, isError = false) {
  message.textContent = text;
  message.classList.toggle("error", isError);
}
function languageName(code) {
  return languages.find(item => item[0] === code)?.[1] || code;
}

translateButton.addEventListener("click", async () => {
  const text = sourceText.value.trim();
  if (!text) {
    setMessage("Please enter some text to translate.", true);
    sourceText.focus();
    return;
  }
  if (sourceSelect.value !== "autodetect" && sourceSelect.value === targetSelect.value) {
    setMessage("Choose two different languages.", true);
    return;
  }

  translateButton.disabled = true;
  translateButton.querySelector("span:first-child").textContent = "Translating...";
  setMessage("Connecting to translation service...");
  translatedText.textContent = "Please wait while we translate your text.";
  translatedText.classList.add("placeholder");
  copyButton.disabled = true;
  speakButton.disabled = true;

  try {
    const langPair = `${sourceSelect.value}|${targetSelect.value}`;
    const endpoint = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${encodeURIComponent(langPair)}`;
    const response = await fetch(endpoint);
    if (!response.ok) throw new Error("The translation service is unavailable. Please try again.");
    const data = await response.json();
    if (data.responseStatus !== 200 || !data.responseData?.translatedText) {
      throw new Error(data.responseDetails || "Translation could not be completed. Please try again.");
    }
    lastTranslation = data.responseData.translatedText;
    translatedText.textContent = lastTranslation;
    translatedText.classList.remove("placeholder");
    copyButton.disabled = false;
    speakButton.disabled = false;
    const detected = data.responseData.detectedLanguage || "";
    const sourceLabel = sourceSelect.value === "autodetect" && detected
      ? `Detected ${detected}` : languageName(sourceSelect.value);
    setMessage(`${sourceLabel} → ${languageName(targetSelect.value)} · Translation complete`);
  } catch (error) {
    translatedText.textContent = "Sorry, translation failed. Check your internet connection and try again.";
    translatedText.classList.add("placeholder");
    setMessage(error.message, true);
  } finally {
    translateButton.disabled = false;
    translateButton.querySelector("span:first-child").textContent = "Translate text";
  }
});

copyButton.addEventListener("click", async () => {
  if (!lastTranslation) return;
  try {
    await navigator.clipboard.writeText(lastTranslation);
    setMessage("Translation copied to clipboard.");
  } catch {
    setMessage("Copy is not available in this browser. Select the translated text to copy.", true);
  }
});

speakButton.addEventListener("click", () => {
  if (!lastTranslation || !("speechSynthesis" in window)) {
    setMessage("Text-to-speech is not supported in this browser.", true);
    return;
  }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(lastTranslation);
  const voices = window.speechSynthesis.getVoices();
  const targetPrefix = targetSelect.value.toLowerCase();
  utterance.lang = targetPrefix;
  const matchingVoice = voices.find(voice => voice.lang.toLowerCase().startsWith(targetPrefix));
  if (matchingVoice) utterance.voice = matchingVoice;
  window.speechSynthesis.speak(utterance);
});

document.getElementById("clearButton").addEventListener("click", () => {
  sourceText.value = "";
  translatedText.textContent = "Your translation will appear here.";
  translatedText.classList.add("placeholder");
  document.getElementById("charCount").textContent = "0 / 5000";
  lastTranslation = "";
  copyButton.disabled = true;
  speakButton.disabled = true;
  setMessage("Powered by the MyMemory Translation API.");
  sourceText.focus();
});

document.getElementById("swapButton").addEventListener("click", () => {
  if (sourceSelect.value === "autodetect") {
    setMessage("Select a source language first to swap languages.", true);
    return;
  }
  const oldSource = sourceSelect.value;
  sourceSelect.value = targetSelect.value;
  targetSelect.value = oldSource;
  const oldText = sourceText.value;
  if (lastTranslation) sourceText.value = lastTranslation;
  translatedText.textContent = oldText || "Your translation will appear here.";
  translatedText.classList.toggle("placeholder", !oldText);
  document.getElementById("charCount").textContent = `${sourceText.value.length} / 5000`;
  lastTranslation = oldText;
  copyButton.disabled = !oldText;
  speakButton.disabled = !oldText;
  setMessage("Languages swapped.");
});
