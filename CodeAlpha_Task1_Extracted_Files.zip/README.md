# CodeAlpha — Language Translation Tool

A responsive Language Translation Tool built for **CodeAlpha AI Internship Task 1**.

## Features
- Enter text and select source and target languages.
- Automatic source-language detection.
- Translation through the MyMemory Translation API.
- Display translated text clearly.
- Copy translated text.
- Listen to translated text using browser Text-to-Speech.
- Swap languages and clear the input.
- Responsive layout for desktop and mobile.

## Technologies
HTML5, CSS3, JavaScript, Fetch API, MyMemory Translation API, Web Speech API.

## Run locally
1. Download this project.
2. Open `index.html` in a modern browser.
3. Enter text, choose the target language, and click **Translate text**.
4. Internet access is required for translation.

For best results, use VS Code Live Server or host the files on GitHub Pages.

## API
MyMemory Translation API: https://api.mymemory.translated.net/get

The API is a third-party service and may apply availability or usage limits. Do not translate confidential or sensitive information using a public API.

## GitHub repository name
`CodeAlpha_Language_Translation_Tool`

## CodeAlpha submission checklist
- [ ] Test multiple language pairs.
- [ ] Upload the complete source code to GitHub.
- [ ] Record a short project explanation video.
- [ ] Post the video on LinkedIn with the GitHub repository link.
- [ ] Submit using the CodeAlpha submission form.
